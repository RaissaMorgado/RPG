
	var $valde = $("#div-valde-leos");
	var $forest_saida = $("#div-portalf");
	var $leos = $("#div-leos");
	
		// Movimentos valde
		$(document).keydown( function(e){
			switch (e.which) {
				case 37:
				    $valde.css('left', $valde.offset().left - 10);
				   	break;
				case 38:
				    $valde.css('top', $valde.offset().top - 10);
				    break;
				case 39:
				    $valde.css('left', $valde.offset().left + 10);
				    break;
				case 40:
				    $valde.css('top', $valde.offset().top + 10);
				    break;
		   	}
			   
			// Colisão com saida do portal (redirect)
			if ((parseInt($valde.css('left')) == parseInt($forest_saida.css('left'))) &&
			   	parseInt($valde.css('top')) == parseInt($forest_saida.css('top'))) {
			   		window.location.replace('field3.html');
			}

			// Colisão com Leos (redirect)
			if ((parseInt($valde.css('left')) == (parseInt($leos.css('left'))+20)) &&
			   	parseInt($valde.css('top')) == parseInt($leos.css('top'))) {
			   		window.location.replace('finalbattle.html');
			}   		
		});