
	//Nao precisamos mais de Zane nem Ann, mas
	//ainda precisamos do hotel caso o jogador
	//resolva voltar la.
	var $valde = $("#div-valde");
	var $hotel = $("#div-hotel");
	var $saida = $("#div-saida");
	var $forest = $("#div-forest");
	var $leos = $("#div-leos");
	
		// Movimentos valde
		$(document).keydown( function(e){
			switch (e.which) {
				case 37:
				    $valde.css('left', $valde.offset().left - 10);
				   	break;
				case 38:
				    $valde.css('top', $valde.offset().top - 10);
				    break;
				case 39:
				    $valde.css('left', $valde.offset().left + 10);
				    break;
				case 40:
				    $valde.css('top', $valde.offset().top + 10);
				    break;
		   	}

			   	
			// Colisão com entrada hotel (redirect)
			if ((parseInt($valde.css('left')) == parseInt($hotel.css('left'))) &&
			   	parseInt($valde.css('top')) == parseInt($hotel.css('top'))) {
			   		window.location.replace('hotel2.html');
			}
			// Colisão com saida hotel (Redirect)
			if ((parseInt($valde.css('left')) == parseInt($saida.css('left'))) &&
			   	parseInt($valde.css('top')) == parseInt($saida.css('top'))) {
			   		window.location.assign("field3.html");
			}
			   		
			// Colisão com entrada do portal (redirect)
			if ((parseInt($valde.css('left')) == parseInt($forest.css('left'))) &&
			   	parseInt($valde.css('top')) == parseInt($forest.css('top'))) {
					window.location.assign("leos.html");
			}  		
		});