	
	//Aqui nao precisamos mais do Zane,
	//e agora precisamos da Ann e da saida do hotel
	var $valde = $("#div-valde");
	var $hotel = $("#div-hotel");
	var $saida = $("#div-saida");
	var $ann = $("#div-ann");
	var $forest = $("#div-forest");

		//Movimentos valde
		$(document).keydown( function(e){
			switch (e.which) {
				case 37:
				    $valde.css('left', $valde.offset().left - 10);
				   	break;
				case 38:
				    $valde.css('top', $valde.offset().top - 10);
				    break;
				case 39:
				    $valde.css('left', $valde.offset().left + 10);
				    break;
				case 40:
				    $valde.css('top', $valde.offset().top + 10);
				    break;
		   	}

			//Colisão com entrada do hotel (redirect)
			   	if ((parseInt($valde.css('left')) == parseInt($hotel.css('left'))) &&
			   		parseInt($valde.css('top')) == parseInt($hotel.css('top'))) {
			   			window.location.replace('hotel.html');
			   	}
			//Colisão com saida do hotel (redirect)
			   	if ((parseInt($valde.css('left')) == parseInt($saida.css('left'))) &&
			   		parseInt($valde.css('top')) == parseInt($saida.css('top'))) {
			   			window.top.location.href = "batalhavencida.html"; 
			   	}
			//Colisão com Ann (redirect)
			   	if ((parseInt($valde.css('left')) == (parseInt($ann.css('left'))-20)) &&
			   		parseInt($valde.css('top')) == parseInt($ann.css('top'))) {
			   			window.location.assign("batalhann.html");
			   	}
			//Colisão com entrada do portal (alert)
			   if ((parseInt($valde.css('left')) == parseInt($forest.css('left'))) &&
			   		parseInt($valde.css('top')) == parseInt($forest.css('top'))) {
			   			alert('Você precisa vencer Ann antes de entrar aqui.');
			   	}		
		});