	
	//Nesse momento do jogo precisamos apenas do Zane, 
	//da entrada do hotel e da entrada do portal.
	var $valde = $("#div-valde");
	var $zane = $("#div-zane");
	var $hotel = $("#div-hotel");
	var $forest = $("#div-forest");
	
		// Movimentos valde
		$(document).keydown( function(e){
			switch (e.which) {
				case 37:
				    $valde.css('left', $valde.offset().left - 10);
				   	break;
				case 38:
				    $valde.css('top', $valde.offset().top - 10);
				    break;
				case 39:
				    $valde.css('left', $valde.offset().left + 10);
				    break;
				case 40:
				    $valde.css('top', $valde.offset().top + 10);
				    break;
		   	}

			// Colisão com zane (redirect p/ batalha)
			if ((parseInt($valde.css('left')) == parseInt($zane.css('left'))) && 
				parseInt($valde.css('top')) == (parseInt($zane.css('top'))+20)) {
				   	window.location.assign("proxima.html");
			}

			// Colisão com entrada do hotel (alert)
			if ((parseInt($valde.css('left')) == parseInt($hotel.css('left'))) &&
				parseInt($valde.css('top')) == parseInt($hotel.css('top'))) {
				   	alert('Você precisa vencer Zane antes de entrar aqui.');	
			}
				   
			// Colisão com entrada do portal (alert)
			if ((parseInt($valde.css('left')) == parseInt($forest.css('left'))) &&
				parseInt($valde.css('top')) == parseInt($forest.css('top'))) {
				   	alert('Você precisa vencer Zane e Ann antes de entrar aqui.');
			}
			   	
		});

